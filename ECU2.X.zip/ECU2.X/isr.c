/*
 * File:   isr.c
 * Author: USER
 *
 * Created on September 22, 2025, 2:13 PM
 */


#include <xc.h>

void main(void) {
    return;
}
