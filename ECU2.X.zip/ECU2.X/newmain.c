/*
 * File:   newmain.c
 * Author: ANANYA 
 *
 * Created on September 19, 2025, 2:02 PM
 */

#include <xc.h>
#include "Adc.h"
#include "ssd.h"
#include "digital_keypad.h"
#include "timer.h"
#include "isr.h"
#include "msg_id.h"
#include "can.h"
#include "uart.h"
#include "mssg_id.h"

#define _XTAL_FREQ 20000000

unsigned char rpm[4];    // Array to store RPM digits as ASCII
unsigned int flag = 0;    // General-purpose flag (not used in this snippet)


// Function to read ADC value, calculate RPM, convert to ASCII digits, and transmit via CAN
int get_rpm()
{
    int adc_value, rpm_value;

    adc_value = read_adc(CHANNEL4);                 // Read ADC value from channel 4
    rpm_value = (adc_value / 10.23) * 60;          // Convert ADC value to RPM

    // Convert RPM to individual ASCII digits
    rpm[3] = ((rpm_value % 10) + '0');             
    rpm[2] = (((rpm_value / 10) % 10) + '0');      
    rpm[1] = (((rpm_value / 100) % 10) + '0');     
    rpm[0] = ((rpm_value / 1000) + '0');           
    rpm[4] = '\0';                                 // Null terminate string

    can_transmit(RPM_MSG_ID, rpm, 4);              // Send RPM data via CAN
    __delay_us(100);                               
}


void main(void) 
{
    TRISB = TRISB | 0x80;      

    // Initialize all peripherals
    init_adc();                 // Initialize ADC module
    init_timer0();              // Initialize Timer0
    init_can();                 // Initialize CAN module
    PORTB = 0x00;               // Clear PORTB outputs
    init_uart();                // Initialize UART
    init_clcd();                // Initialize character LCD
    init_digital_keypad();      // Initialize keypad

    unsigned char key;          // Variable to store pressed key
    unsigned char indicator_arr[2]; // Array to store indicator status

    while (1)
    {
        get_rpm();                              // Read RPM and transmit via CAN
        key = read_digital_keypad(STATE_CHANGE); // Read key press from digital keypad

        // Update indicator based on key pressed
        if (key == SWITCH1)
            indicator_arr[0] = '1';            // Set indicator 1
        if (key == SWITCH3)
            indicator_arr[0] = '2';            // Set indicator 2
        if (key == SWITCH2)
            indicator_arr[0] = '0';            // Turn off indicator

        indicator_arr[1] = '\0';                // Null terminate indicator string

        can_transmit(INDICATOR_MSG_ID, indicator_arr, 1); // Send indicator status via CAN
        __delay_ms(80);                         // Delay to stabilize CAN transmission
    }
}
